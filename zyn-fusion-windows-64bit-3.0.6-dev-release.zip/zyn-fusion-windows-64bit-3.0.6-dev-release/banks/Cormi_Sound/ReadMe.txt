                                                                                           January  28th  2013

Dear friend,
here's an improved version of my instruments, release V2.0
There are two banks: sound and noise.

Maybe in the next times I'll need three of them.

I like fantasy sounds, the zyn instruments do not reflect real instruments.
Some are modified copies created by others.

I'm using ZynAddSubFx in almost all of my compositions. They are oriented to background sounds for narration.
So the instruments want to suggest atmospheres, feelings, and are not finalized to songs.
Often I mix two or three instruments simultaneously to produce a full sound.


You can hear some of them in: 
http://www.freesound.org/search/?q=cormi&f=duration%3A%5B0+TO+*%5D&s=created+desc&advanced=1&a_username=1&g=1



I hope you'll enjoy my work as I enjoyed those that people wanted to share with me.




cormi
